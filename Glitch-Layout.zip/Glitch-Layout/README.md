Glitch Layout
=================

A simple HTML5 layout for ContentBox